<?php

require __DIR__ . '/vendor/autoload.php';

use Orhanerday\OpenAi\OpenAi;

$open_ai = new OpenAi('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');

// get prompt param that we send from js file
$prompt = $_POST['prompt'];

$complete = $open_ai->image([
    "prompt" => $prompt,
    "n" => 3, // number of images
    "size" => "256x256", //image dimension
    "response_format" => "b64_json" // use "url" for less credit usage
]);

echo $complete;


?>